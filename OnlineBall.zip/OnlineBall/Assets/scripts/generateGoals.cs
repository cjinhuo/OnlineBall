﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;
public class generateGoals :NetworkBehaviour{

    public static List<positionGoals> pG = new List<positionGoals>();
    public static List<positionFires> pF = new List<positionFires>();
    public static List<positionRandom> pR = new List<positionRandom>();
    public GameObject goalsPrefab;
    public GameObject firesPrefab;
    public GameObject randomPrefab;

    public override void OnStartServer()
    {
        BindAllRandomData();
        RandomGoals();
        RandomFires();
        RandomRandom();
    }




    private void BindAllRandomData()
    {
        positionGoals pg1 = new positionGoals(new Vector3((float)(-0.18), (float)(1.39), (float)(-1.88)));
        positionGoals pg2 = new positionGoals(new Vector3((float)(16.25), (float)(-35.7), (float)(188.96)));
        positionGoals pg3 = new positionGoals(new Vector3((float)(37.62), (float)(15.26), (float)(128.29)));
        positionGoals pg4 = new positionGoals(new Vector3((float)(75.86), (float)(7.66), (float)(169.33)));
        positionGoals pg5 = new positionGoals(new Vector3((float)(101.95), (float)(1), (float)(201.33)));
        positionGoals pg6 = new positionGoals(new Vector3((float)(135.98), (float)(11.7), (float)(207.63)));
        positionGoals pg7 = new positionGoals(new Vector3((float)(118.29), (float)(4.57), (float)(217.11)));
        positionGoals pg8 = new positionGoals(new Vector3((float)(147.02), (float)(2.87), (float)(80.05)));
        positionGoals pg9 = new positionGoals(new Vector3((float)(140.98), (float)(1), (float)(71.862)));
        positionGoals pg10 = new positionGoals(new Vector3((float)(169.86), (float)(1.4), (float)(124.17)));
        positionGoals pg11 = new positionGoals(new Vector3((float)(87.508), (float)(1), (float)(49.4)));
        positionGoals pg12 = new positionGoals(new Vector3((float)(82.209), (float)(1), (float)(49.4)));
        positionGoals pg13 = new positionGoals(new Vector3((float)(82.209), (float)(1), (float)(37.844)));
        positionGoals pg14 = new positionGoals(new Vector3((float)(80.5), (float)(1), (float)(26.7)));
        positionGoals pg15 = new positionGoals(new Vector3((float)(86.8), (float)(1), (float)(6.1067)));
        positionGoals pg16 = new positionGoals(new Vector3((float)(106.9), (float)(1), (float)(-0.2)));
        positionGoals pg17 = new positionGoals(new Vector3((float)(165.38), (float)(14.78), (float)(-58.97)));
        positionGoals pg18 = new positionGoals(new Vector3((float)(130.29), (float)(3.53), (float)(-99.22)));
        positionGoals pg19 = new positionGoals(new Vector3((float)(112.17), (float)(1), (float)(-67.34)));
        positionGoals pg20 = new positionGoals(new Vector3((float)(76.843), (float)(1), (float)(-37.72)));

        pG.Add(pg1);
        pG.Add(pg2);
        pG.Add(pg3);
        pG.Add(pg4);
        pG.Add(pg5);
        pG.Add(pg6);
        pG.Add(pg7);
        pG.Add(pg8);
        pG.Add(pg9);
        pG.Add(pg10);
        pG.Add(pg11);
        pG.Add(pg12);
        pG.Add(pg13);
        pG.Add(pg14);
        pG.Add(pg15);
        pG.Add(pg16);
        pG.Add(pg17);
        pG.Add(pg18);
        pG.Add(pg19);
        pG.Add(pg20);


        positionFires pf1 = new positionFires(new Vector3((float)(0.12), (float)(5.23), (float)(-1.11)));
        positionFires pf2 = new positionFires(new Vector3((float)(16.46), (float)(-33.89), (float)(169.26)));
        positionFires pf3 = new positionFires(new Vector3((float)(6.12), (float)(6.68), (float)(100.29)));
        positionFires pf4 = new positionFires(new Vector3((float)(85.28), (float)(2.04), (float)(187.58)));
        positionFires pf5 = new positionFires(new Vector3((float)(126.75), (float)(1), (float)(205.6)));
        positionFires pf6 = new positionFires(new Vector3((float)(169.86), (float)(1.4), (float)(163.73)));
        positionFires pf7 = new positionFires(new Vector3((float)(169.86), (float)(1.4), (float)(149)));
        positionFires pf8 = new positionFires(new Vector3((float)(169.86), (float)(1.4), (float)(135)));
        positionFires pf9 = new positionFires(new Vector3((float)(169.86), (float)(1.4), (float)(113)));
        positionFires pf10 = new positionFires(new Vector3((float)(169.86), (float)(1.4), (float)(96)));
        positionFires pf11 = new positionFires(new Vector3((float)(138.67), (float)(1), (float)(84.12)));
        positionFires pf12 = new positionFires(new Vector3((float)(124.33), (float)(1), (float)(1.6218)));
        positionFires pf13 = new positionFires(new Vector3((float)(153.96), (float)(1), (float)(3.02)));
        positionFires pf14 = new positionFires(new Vector3((float)(167.70), (float)(9.218), (float)(-19.54)));
        positionFires pf15 = new positionFires(new Vector3((float)(117.8), (float)(1), (float)(-87.9)));
        positionFires pf16 = new positionFires(new Vector3((float)(105.44), (float)(1), (float)(-49.85)));
        positionFires pf17 = new positionFires(new Vector3((float)(66.6), (float)(1), (float)(-42)));

        pF.Add(pf1);
        pF.Add(pf2);
        pF.Add(pf3);
        pF.Add(pf4);
        pF.Add(pf5);
        pF.Add(pf6);
        pF.Add(pf7);
        pF.Add(pf8);
        pF.Add(pf9);
        pF.Add(pf10);
        pF.Add(pf11);
        pF.Add(pf12);
        pF.Add(pf13);
        pF.Add(pf14);
        pF.Add(pf15);
        pF.Add(pf16);
        pF.Add(pf17);

        positionRandom pr1 = new positionRandom(new Vector3((float)(26.1), (float)(13.5), (float)(117.8)));
        positionRandom pr2 = new positionRandom(new Vector3((float)(169.92), (float)(2.54), (float)(184.56)));
        positionRandom pr3 = new positionRandom(new Vector3((float)(138.69), (float)(6.86), (float)(77.96)));
        positionRandom pr4 = new positionRandom(new Vector3((float)(99.112), (float)(2), (float)(66.6)));
        positionRandom pr5 = new positionRandom(new Vector3((float)(167.36), (float)(12), (float)(-44.10)));
        positionRandom pr6 = new positionRandom(new Vector3((float)(157.37), (float)(2), (float)(-93.71)));
        positionRandom pr7 = new positionRandom(new Vector3((float)(91.14), (float)(2), (float)(-35.79)));
        pR.Add(pr1);
        pR.Add(pr2);
        pR.Add(pr3);
        pR.Add(pr4);
        pR.Add(pr5);
        pR.Add(pr6);
        pR.Add(pr7);
    }

    public void RandomGoals()
    {
        List<int> randomGoals = getRandomNumBetweenMinAndMax(12, 0, 19);

        foreach (int r in randomGoals)
        {
            GameObject a = GameObject.Instantiate(goalsPrefab, pG[r].position, goalsPrefab.transform.rotation);
            NetworkServer.Spawn(a);
        }
    }

    public void RandomFires()
    {
        List<int> randomFires = getRandomNumBetweenMinAndMax(10, 0, 16);

        foreach (int r in randomFires)
        {
            GameObject a = GameObject.Instantiate(firesPrefab, pF[r].position, firesPrefab.transform.rotation);
            NetworkServer.Spawn(a);
        }
    }

    public void RandomRandom()
    {
        List<int> randomRandom = getRandomNumBetweenMinAndMax(5, 0, 7);

        foreach (int r in randomRandom)
        {
            GameObject a = GameObject.Instantiate(randomPrefab, pR[r].position, randomPrefab.transform.rotation);
            NetworkServer.Spawn(a);
        }
    }



    /// <summary>
    /// 取num个在min - max的不重复随机数
    /// </summary>
    /// <param name="num"></param>
    /// <param name="min"></param>
    /// <param name="max"></param>
    /// <returns></returns>
    public static List<int> getRandomNumBetweenMinAndMax(int num, int min, int max)
    {
        List<int> result = new List<int>();
        bool flag;
        for (int i = 0; i < num;)
        {
            flag = true;
            System.Random ran = new System.Random();
            int n = ran.Next(min, max);
            foreach (int r in result)
            {
                if (r == n)
                {
                    flag = false;
                    break;
                }
            }
            if (flag)
            {
                result.Add(n);
                i++;
            }
        }
        return result;
    }

    public class positionGoals
    {
        public Vector3 position;
        public positionGoals(Vector3 position)
        {
            this.position = position;
        }
    }

    public class positionFires
    {
        public Vector3 position;
        public positionFires(Vector3 position)
        {
            this.position = position;
        }
    }
    public class positionRandom
    {
        public Vector3 position;
        public positionRandom(Vector3 position)
        {
            this.position = position;
        }
    }
}
