﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class NetUIController : MonoBehaviour {

    public GameObject objCanvas;
    public Slider load;
	// Use this for initialization
	void Start () {
        objCanvas = GameObject.Find("Canvas");
        load = objCanvas.transform.Find("Loading/Slider").GetComponent<Slider>();
        objCanvas.transform.Find("Panel/btn_setup").GetComponent<Button>().onClick.AddListener(StartHost);
	}
	
    void StartHost()
    {
        objCanvas.transform.Find("Loading").gameObject.SetActive(true);
    }

}
