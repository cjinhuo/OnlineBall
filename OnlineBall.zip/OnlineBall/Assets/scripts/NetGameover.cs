﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;
public class NetGameover : NetworkBehaviour {
    [SyncVar]
    public bool OneGameover;

    [SyncVar]
    public bool AllPlayersGameover;

    [SyncVar]
    public bool Temp;

    [SyncVar]
    public bool AllPlayersStart;

    [SyncVar]
    public int count;

    [SyncVar]
    public string NowPlayersIP;


    public GameObject[] balls;

    //private void Update()
    //{
    //    balls = GameObject.FindGameObjectsWithTag("Player");
    //}
}
