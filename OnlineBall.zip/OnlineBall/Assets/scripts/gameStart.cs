﻿//using System;
//using System.Collections;
//using System.Collections.Generic;
//using System.Text;
//using UnityEngine;
//using UnityEngine.SceneManagement;
//using UnityEngine.UI;
//using UnityEngine.Networking;
//public class gameStart : NetworkBehaviour {
//    private bool flag;
//    public Text grade;
//    Text time;
//    public DateTime startTime;
//    public GameObject objCanvas;
//    public GameObject PanelGameover;
//    public GameObject PanelStart;
//    public GameObject PanelCharts;
//    public ulong overGrade;
//    public static bool allPlayersStart;
//    Animator Ani;
//    // Use this for initialization
//    void Start () {
//        if (isClient)
//        {

//        }
//        if (isServer)
//        {

//        }
//        StartInit();
//    }


//    // Update is called once per frame
//    void Update () {

//		if (time != null && ballCollider.gameover != true)
//        {
//            time.text = (DateTime.Now - startTime).ToString();
//        }
//        if (ballCollider.gameover == true)
//        {
//            if (flag)
//            {
//                PanelGameover.transform.Find("getGoals").GetComponent<Text>().text =
//                    string.Format("你碰到了{0}次障碍物(加一秒),抓到了{1}个金币(减五秒)", ballCollider.obstacles, ballCollider.goals);
//                overGrade = (ulong)TimeSpan.Parse(time.text).TotalSeconds + (ulong)(ballCollider.obstacles) - (ulong)(ballCollider.goals * 5);
//                PanelGameover.transform.Find("gameoverGrade").GetComponent<Text>().text = "用时:" 
//                    + overGrade + "秒";
                
//                PanelGameover.SetActive(true);
//                flag = false;
//            }
//         }
//}



//    private void btnStart_Click()
//    {
//        Debug.Log("start");
//        objCanvas.transform.Find("time").gameObject.SetActive(true);
//        PanelStart.SetActive(false);
//        //如果是房主开始则所有人都可以动
//        allPlayersStart = true;
//        //计时器
//        startTime = DateTime.Now;
//        GameObject objTime = GameObject.Find("gameoverGrade");
//        GameObject timeUpdate = GameObject.Find("Canvas/time");
//        if (objTime != null)
//        {
//            grade = objTime.GetComponent<Text>();
//        }
//        if (timeUpdate != null)
//        {
//            time = timeUpdate.GetComponent<Text>();
//        }
//        flag = true;
//    }

//    /// <summary>
//    /// 输入姓名,保存成绩
//    /// </summary>
//    private void btnGameover_Click()
//    {
//        string name = PanelGameover.transform.Find("inputName").GetComponent<InputField>().text;
//        GradeRecord.AddGrade(name, TimeSpan.Parse(overGrade.ToString()));
//        SceneManager.LoadScene("Main");
//    }



//    /// <summary>
//    /// 排行榜按钮
//    /// </summary>
//    private void btnChart_Click()
//    {
//        Debug.Log("chart");
//        List<Grade> lstGrade = GradeRecord.GetRecord();
//        StringBuilder gradeText = new StringBuilder();
//        if (lstGrade != null && lstGrade.Count > 0)
//        {
//            for (int i = 0; i < lstGrade.Count & i < 10; i++)
//            {
//                gradeText.AppendFormat("{0}.{2}:\t{1}秒\n",
//                    i + 1,
//                    lstGrade[i].Time,
//                    lstGrade[i].Name);
//            }
//        }
//        PanelCharts.transform.Find("textGrade").gameObject.GetComponent<Text>().text = gradeText.ToString();
//        Ani.SetTrigger("ChartInTri");

//    }
//    /// <summary>
//    /// 退出游戏
//    /// </summary>
//    private void btnQuit_Click()
//    {
//        Debug.Log("quit");
//        //Application.Quit();
//    }
//    /// <summary>
//    /// 排行榜返回按钮
//    /// </summary>
//    private void btnChartBack_Click()
//    {
//        Debug.Log("ChartBack");
//        Ani.SetTrigger("ChartOutTri");
//    }





//    private void StartInit()
//    {

        
//        objCanvas = GameObject.Find("Canvas");
//        PanelGameover = objCanvas.transform.Find("PanelGameover").gameObject;
//        PanelGameover.SetActive(false);
//        PanelStart = objCanvas.transform.Find("PanelStart").gameObject;
//        PanelStart.SetActive(true);
//        PanelCharts = objCanvas.transform.Find("PanelCharts").gameObject;
//        Ani = PanelCharts.GetComponent<Animator>();
//        PanelCharts.SetActive(true);

//        //绑定按钮
//        GameObject.Find("Canvas/PanelStart/btnStart").GetComponent<Button>().onClick.AddListener(btnStart_Click);
//        GameObject.Find("Canvas/PanelStart/btnChart").GetComponent<Button>().onClick.AddListener(btnChart_Click);
//        GameObject.Find("Canvas/PanelStart/btnQuit").GetComponent<Button>().onClick.AddListener(btnQuit_Click);
//        //GameObject.Find("name")找不到被隐藏的控件
//        //
//        PanelGameover.transform.Find("confirmGameover").GetComponent<Button>().onClick.AddListener(btnGameover_Click);
//        PanelCharts.transform.Find("chartBack").GetComponent<Button>().onClick.AddListener(btnChartBack_Click);
//        if (isClient)
//        {
//            GameObject.Find("Canvas/PanelStart/btnStart").SetActive(false);
//        }
//        if (isServer)
//        {
//            GameObject.Find("Canvas/PanelStart/btnStart").SetActive(true);
//        }
//    }
//}
