﻿using System.Collections.Generic;
using CLSerialize;
using System.Linq;
using System;

public class GradeRecord {



    static string RecordFile = "Data.bin";

    /// <summary>
    /// 添加成绩
    /// </summary>
    /// <param name="name">Name.</param>
    /// <param name="time">Time.</param>
    public static void AddGrade(string name, TimeSpan time)
    {
        //从文件加载成绩列表对象
        List<Grade> lstGrade = SerializeXml<List<Grade>>.Load(RecordFile);

        if (lstGrade == null)
        {
            lstGrade = new List<Grade>();
        }
        lstGrade.Add(new Grade(name, time));
        //对象成绩进行排序并重新保存
        lstGrade = lstGrade.OrderBy<Grade, TimeSpan>(grd => grd.Time).ToList();

        SerializeXml<List<Grade>>.Save(lstGrade, RecordFile);
    }


    public static List<Grade> GetRecord()
    {
        //从文件中加载成绩列表对象
        return SerializeXml<List<Grade>>.Load(RecordFile);
    }
}
