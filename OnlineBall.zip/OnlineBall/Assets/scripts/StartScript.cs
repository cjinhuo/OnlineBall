﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
public class StartScript : MonoBehaviour {

    public GameObject ObjCanvas;
	// Use this for initialization
	void Start () {
        ObjCanvas = GameObject.Find("Canvas");
        GameObject.Find("Canvas/Panel/start").GetComponent<Button>().onClick.AddListener(btnStart_Click);
        GameObject.Find("Canvas/Panel/about").GetComponent<Button>().onClick.AddListener(btnAbout_Click);
        GameObject.Find("Canvas/Panel/quit").GetComponent<Button>().onClick.AddListener(btnQuit_Click);
        GameObject.Find("Canvas/Panel/author").GetComponent<Button>().onClick.AddListener(btnAuthor_Click);

        ObjCanvas.transform.Find("PanelAbout").gameObject.SetActive(false);
        ObjCanvas.transform.Find("AboutAuthor").gameObject.SetActive(false);

        ObjCanvas.transform.Find("PanelAbout/back").GetComponent<Button>().onClick.AddListener(btnBack_Click);
        ObjCanvas.transform.Find("AboutAuthor/authorBack").GetComponent<Button>().onClick.AddListener(btnAuthorBack_Click);

    }


    private void btnAuthor_Click()
    {
        ObjCanvas.transform.Find("AboutAuthor").gameObject.SetActive(true);
    }


    private void btnAuthorBack_Click()
    {
        ObjCanvas.transform.Find("AboutAuthor").gameObject.SetActive(false);
    }
    private void btnBack_Click()
    {
        ObjCanvas.transform.Find("PanelAbout").gameObject.SetActive(false);
    }
    private void btnStart_Click()
    {
        SceneManager.LoadScene("Connect");
    }

    private void btnAbout_Click()
    {
        ObjCanvas.transform.Find("PanelAbout").gameObject.SetActive(true);
    }

    private void btnQuit_Click()
    {
        Application.Quit();
    }


}
