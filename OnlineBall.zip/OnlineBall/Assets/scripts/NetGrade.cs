﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NetGrade  {

    public string Name { get; set; }

    public int Time { get; set; }

    public string IP { get; set; }

    public NetGrade(string n, int t)
    {
        Name = n;
        Time = t;
    }
}
