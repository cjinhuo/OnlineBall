﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RotationBySelf : MonoBehaviour {


	
	// Update is called once per frame
	void Update () {
        //自动旋转,挂到goals，fires预设体身上
        this.GetComponent<Transform>().Rotate(0, 180 * Time.deltaTime, 0, Space.Self);
	}
}
