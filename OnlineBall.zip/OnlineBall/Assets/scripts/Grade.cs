﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[Serializable]
public class Grade {

    public string Name { get; set; }

    public TimeSpan Time { get; set; }


    public Grade(string n, TimeSpan t)
    {
        Name = n;
        Time = t;
    }
}
