﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Networking;
using System.Threading;
public class ballCollider : NetworkBehaviour
{
    // Use this for initialization


    public GameObject particalPrefab;
    public int obstacles;
    public int goals;
    public Slider speedSlider;
    public AudioClip goalsSound;
    public AudioClip fireSound;
    public AudioClip otherSound;
    public AudioClip gameoverSound;
    public AudioClip speedUpSound;
    public GameObject objCanvas;
    public Text gameovercount;
    public AudioClip countSound;
    private Color temp;
    public  bool localGameOver;
    public GameObject GameOverObj;
    public GameObject p;

    private void Start()
    {
        objCanvas = GameObject.Find("Canvas");
        speedSlider = GameObject.Find("speed").GetComponent<Slider>();
        gameovercount = GameObject.Find("count").GetComponent<Text>();
        localGameOver = false;
        obstacles = 0;
        goals = 0;
        speedSlider.maxValue = 100;
        GameOverObj = GameObject.Find("GameOver");
        GameOverObj.GetComponent<NetGameover>().OneGameover = true;
        GameOverObj.GetComponent<NetGameover>().AllPlayersGameover = false;
    }



    


    private void Update()
    {

        Debug.Log("ballcollidercount:" + GameOverObj.GetComponent<NetGameover>().count);
        if (isLocalPlayer)
        {
            if (p != null)
            {
                p.transform.position = gameObject.transform.position;
            }
        }
            if (!GameOverObj.GetComponent<NetGameover>().OneGameover)
            {
                //倒计时开始时放背景音乐
                if (GameOverObj.GetComponent<NetGameover>().count == 10)
                {
                    CmdPlayMs();
                }
                if (GameOverObj.GetComponent<NetGameover>().count == 0)
                {
                    if(isServer)
                    {
                        GameOverObj.GetComponent<NetGameover>().AllPlayersGameover = true;
                    }

                    Debug.Log("allplayer:" + GameOverObj.GetComponent<NetGameover>().AllPlayersGameover);
                    CancelInvoke("countSecond");
                    CmdPauseMs();
                }
        }
    }
    [Command]
    void CmdPlayMs()
    {
        gameObject.GetComponent<AudioSource>().Play();
    }
    [Command]
    void CmdPauseMs()
    {
        gameObject.GetComponent<AudioSource>().Pause();
    }
    private void OnGUI()
    {
        if (speedSlider.value == 100)
        {
            if (Input.GetKeyDown(KeyCode.R))
            {
                if (isLocalPlayer)
                {
                    gameObject.GetComponent<MyBall>().m_MaxAngularVelocity = 80;
                    gameObject.GetComponent<MyBall>().m_MovePower = 20000;
                    gameObject.GetComponent<MyBall>().m_JumpPower = 3;
                    speedSlider.value = 0;
                    AudioSource.PlayClipAtPoint(speedUpSound, transform.position);
                    if (isServer)
                        RpcTempColorSave();
                    CmdSpawnPartical();
                    Invoke("BackNormal", 4.0f);
                }
            }
        }
    }

    void CmdSpawnPartical()
    {
        p = GameObject.Instantiate(particalPrefab, gameObject.transform.position, Camera.main.transform.rotation * new Quaternion(-1f, 1f, 1f, 1f));
        NetworkServer.Spawn(p);
    }

    [ClientRpc]
    void RpcTempColorSave()
    {
        temp = this.GetComponent<Renderer>().material.color;
        gameObject.GetComponent<Renderer>().material.color = new Color(0, 191, 255, 1f);
    }


    private void BackNormal()
    {
        if (!isLocalPlayer)
            return;
        gameObject.GetComponent<MyBall>().m_MaxAngularVelocity = 25;
        gameObject.GetComponent<MyBall>().m_MovePower = 6;
        gameObject.GetComponent<MyBall>().m_JumpPower = 1;
        DestroyObject(p);
        if (isServer)
            RpcTempColor();
    }
    [ClientRpc]
    void RpcTempColor()
    {
        if (this.GetComponent<Renderer>().material.color == new Color(0, 191, 255, 1f))
        {
            this.GetComponent<Renderer>().material.color = temp;
        }
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.tag == "obstacles")
        {
            this.GetComponent<Renderer>().material.color = new Color(0, 0, 0, 0.8f);
            obstacles++;
        }
    }

    private void countSecond()
    {
        if (isServer)
        {
            GameOverObj.GetComponent<NetGameover>().count--;
        }
        if(isServer)
        RpcCountText();
    }

    [ClientRpc]
    void RpcCountText()
    {
        gameovercount.text = GameOverObj.GetComponent<NetGameover>().count.ToString();

    }
    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "goals")
        {
            if(isServer)
            RpcGoalTrigger();
            Destroy(other.gameObject);
        }
        else if (other.gameObject.tag == "Finish")
        {
            //Destroy(gameObject);
            //Destroy(other.gameObject);
            AudioSource.PlayClipAtPoint(gameoverSound, transform.position);

            if (GameOverObj.GetComponent<NetGameover>().OneGameover)
            {
                if (isServer)
                {
                    GameOverObj.GetComponent<NetGameover>().count = 10;
                    GameOverObj.GetComponent<NetGameover>().OneGameover = false;
                }
                InvokeRepeating("countSecond", 1f, 1f);
            }
            if (isLocalPlayer)
            {
                localGameOver = true;
            }

        }
        else if (other.gameObject.tag == "fires")
        {
            Destroy(other.gameObject);
            if (isServer)
                RpcFireTrigger();
        }
        else if (other.gameObject.tag == "random")
        {
            AudioSource.PlayClipAtPoint(otherSound, transform.position);
            System.Random ran = new System.Random();
            int randomNum = ran.Next(0, 3);
            Destroy(other.gameObject);
            switch (randomNum)
            {
                case 0:
                    if (isServer)
                        RpcGoalTrigger();
                    break;
                case 1:
                    if (isServer)
                        RpcFireTrigger();
                    break;
                case 3:
                    AudioSource.PlayClipAtPoint(otherSound, transform.position);
                    obstacles++;
                    this.GetComponent<Renderer>().material.color = new Color(0, 0, 0, 0.8f);
                    break;
                default: break;
            }
        }
    }


    [ClientRpc]
    private void RpcGoalTrigger()
    {

        this.GetComponent<Renderer>().material.color = new Color(255, 215, 0, 0.8f);
        goals++;
        AudioSource.PlayClipAtPoint(goalsSound, transform.position);


    }
    [ClientRpc]
    private void RpcFireTrigger()
    {
        this.GetComponent<Renderer>().material.color = new Color(0, 0, 205, 0.8f);
        AudioSource.PlayClipAtPoint(fireSound, transform.position);
        if (speedSlider.value != 100)
        {
            speedSlider.value = speedSlider.value + (float)20;
        }

    }

}
