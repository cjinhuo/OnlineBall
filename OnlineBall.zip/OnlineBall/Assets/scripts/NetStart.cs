﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;
using UnityEngine.UI;
using UnityEngine.SceneManagement;
public class NetStart : NetworkBehaviour {

    public AsyncOperation async;
    private bool flag;
    private void Start()
    {
        flag = true;
        ConnectLine();
    }



    public void StartHost()
    {
        NetworkServer.Reset();
        StartCoroutine(loadScene());

        //不管async.progress返回多少，先给进度条40%的目标来匀速加载
        //当从当前页面启动时可以开放下面一行代码，过渡效果
        //InvokeRepeating("loadRepeat", 0, 0.05f);
        NetworkManager.singleton.StartHost();

    }
    void ConnectLine()
    {
        GameObject.Find("btn_setup").GetComponent<Button>().onClick.AddListener(StartHost);
        GameObject.Find("btn_connect").GetComponent<Button>().onClick.AddListener(StartClient);
    }
    void loadRepeat()
    {
        if (GameObject.Find("Slider").GetComponent<Slider>().value < 1)
        {
            GameObject.Find("Slider").GetComponent<Slider>().value = GameObject.Find("Slider").GetComponent<Slider>().value + Time.deltaTime * 0.6f;
        }
    }
    void online()
    {
        GameObject.Find("btn_disconnect").GetComponent<Button>().onClick.AddListener(Stop);
    }
    public void StartClient()
    {
        NetworkManager.singleton.networkAddress = GameObject.Find("InputField").GetComponent<InputField>().text;
        //当从当前页面启动时可以开放下面一行代码，过渡效果

        StartCoroutine(loadScene());
        //InvokeRepeating("loadRepeat", 0, 0.05f);
        NetworkManager.singleton.StartClient();
    }

    IEnumerator loadScene()
    {
        async = SceneManager.LoadSceneAsync("Main");

        async.allowSceneActivation = true;
        //当从当前页面启动时可以开放下面一行代码，设置为 加载完场景也要等待进度条到1才能切换场景
        //async.allowSceneActivation = false;

        yield return async;
    }

    private void FixedUpdate()
    {
        if (async != null)
        {

            //当async有不为0时(从当前页面直接启动)可以使用下面的逻辑
            if (GameObject.Find("Slider").GetComponent<Slider>().value >= 0.9 && GameObject.Find("Slider").GetComponent<Slider>().value <= 1)
            {
                GameObject.Find("Slider").GetComponent<Slider>().value = GameObject.Find("Slider").GetComponent<Slider>().value + Time.deltaTime * 0.4f;
            }
            if (GameObject.Find("Slider").GetComponent<Slider>().value < async.progress && GameObject.Find("Slider").GetComponent<Slider>().value > 0.4)
            {
                CancelInvoke("loadRepeat");
                GameObject.Find("Slider").GetComponent<Slider>().value = GameObject.Find("Slider").GetComponent<Slider>().value + Time.deltaTime * 0.3f;  
            }
            if (GameObject.Find("Slider").GetComponent<Slider>().value >= 1)
            {
                async.allowSceneActivation = true;
            }

            //从别的场景加载过来，async的progress为0，async的基本功能都不能用包括（async.allowSceneActivation），所以只能乱写一个过渡.
            //但是async竟然不为空


            if (GameObject.Find("Slider").GetComponent<Slider>().value <= 1)
            {
                GameObject.Find("Slider").GetComponent<Slider>().value = GameObject.Find("Slider").GetComponent<Slider>().value + Time.deltaTime * 0.4f;
            }

        }

    }
    void CancelMethod()
    {
        if (flag)
        {
            CancelInvoke("loadRepeat");
            flag = false;
        }

    }

    public void Stop()
    {
        NetworkManager.singleton.StopHost();
    }

    void OnLevelWasLoaded(int level)
    {
        
        if (level == 1)
        {
            ConnectLine();
        }
        else if(level == 2)
        {
            async = null;
            online();
        }
    }


	
}
