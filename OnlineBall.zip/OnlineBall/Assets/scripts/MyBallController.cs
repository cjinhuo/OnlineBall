﻿using System;
using UnityEngine;
using UnityStandardAssets.CrossPlatformInput;
using UnityEngine.Networking;
using UnityStandardAssets.Cameras;
using UnityEngine.UI;
using System.Collections;
using System.Collections.Generic;
using System.Net.NetworkInformation;
using System.Net.Sockets;
using UnityEngine.SceneManagement;
using System.Text;
using System.Linq;

public class MyBallController : NetworkBehaviour
{
    public string IPBall;
    private MyBall ball; // Reference to the ball controller.
    //public string AllGoals;
    private Vector3 move;
    // the world-relative desired move direction, calculated from the camForward and user input.
    public ulong localOverGrade;
    private Transform cam; // A reference to the main camera in the scenes transform
    private Vector3 camForward; // The current forward direction of the camera
    private bool jump; // whether the jump button is currently pressed
    public GameObject allPlayers;
    public string allPlayersString;
    private bool flag;
    private bool temp;
    public Text grade;
    Text time;
    public DateTime startTime;
    public GameObject objCanvas;
    public GameObject PanelGameover;
    public GameObject PanelStart;
    public GameObject PanelCharts;
    public GameObject GameOverObj;
    public GameObject mainBack;
    public GameObject Rank;
    public ulong overGrade;
    Animator Ani;
    public Slider sliderSpeed;




    private void btnStart_Click()
    {
        RpcStartBtn();
    }
    [ClientRpc]
    void RpcStartBtn()
    {
        objCanvas.transform.Find("time").gameObject.SetActive(true);
        PanelStart.SetActive(false);
        //如果是房主开始则所有人都可以动
        if(isServer)
        GameOverObj.GetComponent<NetGameover>().AllPlayersStart = true;

        //计时器
        startTime = DateTime.Now;
        GameObject objTime = GameObject.Find("gameoverGrade");
        GameObject timeUpdate = GameObject.Find("Canvas/time");
        if (objTime != null)
        {
            grade = objTime.GetComponent<Text>();
        }
        if (timeUpdate != null)
        {
            time = timeUpdate.GetComponent<Text>();
        }
        flag = true;
        temp = true;
    }
    /// <summary>
    /// 输入姓名,保存成绩
    /// </summary>
    private void btnGameover_Click()
    {
        if (!isLocalPlayer)
            return;
        string name = PanelGameover.transform.Find("inputName").GetComponent<InputField>().text;
        GradeRecord.AddGrade(name, TimeSpan.Parse(overGrade.ToString()));
        NetworkServer.Reset();
        if(isClient)
        {
            NetworkManager.singleton.StopClient();
            SceneManager.LoadScene("Start");
        }
        if(isServer)
        {
            NetworkManager.singleton.StopHost();
            SceneManager.LoadScene("Start");
        }

    }

    //[Command]
    //void CmdAddPlayerIP(string ip)
    //{
    //    GameOverObj.GetComponent<NetGameover>().NowPlayersIP = "IP:" + ip + "加入了游戏!\n";
    //}




    /// <summary>
    /// 排行榜按钮
    /// </summary>
    private void btnChart_Click()
    {
        List<Grade> lstGrade = GradeRecord.GetRecord();
        StringBuilder gradeText = new StringBuilder();
        if (lstGrade != null && lstGrade.Count > 0)
        {
            for (int i = 0; i < lstGrade.Count & i < 10; i++)
            {
                gradeText.AppendFormat("{0}.{2}:\t{1}秒\n",
                    i + 1,
                    lstGrade[i].Time,
                    lstGrade[i].Name);
            }
        }
        PanelCharts.transform.Find("textGrade").gameObject.GetComponent<Text>().text = gradeText.ToString();
        Ani.SetTrigger("ChartInTri");
    }
    /// <summary>
    /// 退出游戏
    /// </summary>
    private void btnQuit_Click()
    {
        if (!isLocalPlayer)
            return;
        Debug.Log("quit");
        Application.Quit();
    }
    /// <summary>
    /// 排行榜返回按钮
    /// </summary>
    private void btnChartBack_Click()
    {
        if (!isLocalPlayer)
            return;
        Ani.SetTrigger("ChartOutTri");
    }

    private void btnMainBack_Click()
    {
        if (isClient)
        {
            NetworkManager.singleton.StopClient();
            SceneManager.LoadScene("Start");
        }
        if (isServer)
        {
            NetworkManager.singleton.StopHost();
            SceneManager.LoadScene("Start");
        }
    }



    private void btnOverBack_Click()
    {
        if (isClient)
        {
            NetworkManager.singleton.StopClient();
            SceneManager.LoadScene("Start");
        }
        if (isServer)
        {
            NetworkManager.singleton.StopHost();
            SceneManager.LoadScene("Start");
        }
    }

    private void StartInit()
    {
        
        objCanvas = GameObject.Find("Canvas");
        PanelGameover = objCanvas.transform.Find("PanelGameover").gameObject;
        PanelGameover.SetActive(false);
        PanelStart = objCanvas.transform.Find("PanelStart").gameObject;
        
        PanelStart.SetActive(true);

        PanelCharts = objCanvas.transform.Find("PanelCharts").gameObject;
        Ani = PanelCharts.GetComponent<Animator>();
        PanelCharts.SetActive(true);
        sliderSpeed = GameObject.Find("speed").GetComponent<Slider>();
        mainBack = objCanvas.transform.Find("mainBack").gameObject;
        mainBack.SetActive(false);
        //绑定按钮
        GameObject.Find("Canvas/PanelStart/btnStart").GetComponent<Button>().onClick.AddListener(btnStart_Click);
        GameObject.Find("Canvas/PanelStart/btnChart").GetComponent<Button>().onClick.AddListener(btnChart_Click);
        GameObject.Find("Canvas/PanelStart/btnQuit").GetComponent<Button>().onClick.AddListener(btnQuit_Click);


        //GameObject.Find("name")找不到被隐藏的控件
        //
        objCanvas.transform.Find("mainBack").GetComponent<Button>().onClick.AddListener(btnMainBack_Click);
        PanelGameover.transform.Find("confirmGameover").GetComponent<Button>().onClick.AddListener(btnGameover_Click);
        PanelGameover.transform.Find("overBack").GetComponent<Button>().onClick.AddListener(btnOverBack_Click);
        PanelCharts.transform.Find("chartBack").GetComponent<Button>().onClick.AddListener(btnChartBack_Click);
        Rank = PanelGameover.transform.Find("Rank").gameObject;
        if(isLocalPlayer)
        overGrade = 0;
        if (isClient)
        {
            GameObject.Find("Canvas/PanelStart/btnStart").SetActive(false);
        }
        if (isServer)
        {
            GameObject.Find("Canvas/PanelStart/btnStart").SetActive(true);
        }
    }



    private void Awake()
    {
        // Set up the reference.
        ball = GetComponent<MyBall>();
        IPBall = Network.player.ipAddress;
        GameOverObj = GameObject.Find("GameOver");
        allPlayers = GameObject.Find("Canvas/PanelStart/allPlayers");

        // get the transform of the main camera
        if (Camera.main != null)
        {
            cam = Camera.main.transform;
        }
        else
        {
            Debug.LogWarning(
                "Warning: no main camera found. Ball needs a Camera tagged \"MainCamera\", for camera-relative controls.");
            // we use world-relative controls in this case, which may not be what the user wants, but hey, we warned them!
        }
    }






    private void Start()
    {
        StartInit();
        //找到本地的ip地址放在左下角
        if(isLocalPlayer)
        GameObject.Find("IPaddress").GetComponent<Text>().text = Network.player.ipAddress;
        if (isServer)
        {
            GameObject.Find("Canvas/PanelStart/btnStart").GetComponent<Button>().onClick.AddListener(btnStart_Click);
        }
    }


    public override void OnStartClient()
    {
        string tempIP = "";
        GameObject[] balls = GameObject.FindGameObjectsWithTag("Player");
        foreach (GameObject ballTemp in balls)
        {
            tempIP += "IP:" + ballTemp.GetComponent<MyBallController>().IPBall + "加入了游戏\n";
        }
        allPlayers.GetComponent<Text>().text = tempIP;
    }

    public override void OnStartServer()
    {
        
    }
    [Command]
    void CmdStartIP(string tempIP)
    {
        RpcStartIP(tempIP);
    }

    [ClientRpc]
    void RpcStartIP(string tempIP)
    {
        Debug.Log("kehuduan");
        allPlayers.GetComponent<Text>().text = tempIP;
    }



    public List<string> TestIP()
    {
        GameObject[] balls = GameOverObj.GetComponent<NetGameover>().balls;
        List<string> list = new List<string>();

        foreach (GameObject ballTemp in balls)
        {
            list.Add(ballTemp.GetComponent<MyBallController>().IPBall);
         }
        return list;
    }


    private void Update()
    {
        //当开始游戏时，每个客户端的开始界面消失


        if (GameOverObj.GetComponent<NetGameover>().AllPlayersStart)
            PanelStart.SetActive(false);

        //foreach(string ip in TestIP())
        //{
        //    allPlayers.GetComponent<Text>().text = ip;
        //}
        
        //Debug.Log(GameOverObj.GetComponent<NetGameover>().balls[1].GetComponent<MyBallController>().IPBall);
        //如果是本地玩家就可以移动

        if (isLocalPlayer)
        {
            GameObject.Find("FollowBall").GetComponent<FreeLookCam>().m_Target = gameObject.transform;
            float h = CrossPlatformInputManager.GetAxis("Horizontal");
            float v = CrossPlatformInputManager.GetAxis("Vertical");
            jump = CrossPlatformInputManager.GetButton("Jump");

            // calculate move direction
            if (cam != null)
            {
                // calculate camera relative direction to move:
                camForward = Vector3.Scale(cam.forward, new Vector3(1, 0, 1)).normalized;
                move = (v * camForward + h * cam.right).normalized;
            }
            else
            {
                // we use world-relative directions in the case of no main camera
                move = (v * Vector3.forward + h * Vector3.right).normalized;
            }

            if (time != null && gameObject.GetComponent<ballCollider>().localGameOver != true)
            {
                time.text = (DateTime.Now - startTime).ToString();
            }
            //当所有人都结束之后执行以下操作
            
            if (GameOverObj.GetComponent<NetGameover>().AllPlayersGameover)
            {
                if (flag)
                {
                    //到达终点的人会出现成绩结算
                    if (transform.GetComponent<ballCollider>().localGameOver)
                    {
                        

                        GameObject.Find("count").SetActive(false);
                        PanelGameover.transform.Find("getGoals").GetComponent<Text>().text =
                        string.Format("你碰到了{0}次障碍物(加一秒),抓到了{1}个金币(减五秒)", gameObject.GetComponent<ballCollider>().obstacles, gameObject.GetComponent<ballCollider>().goals);
                        overGrade = (ulong)TimeSpan.Parse(time.text).TotalSeconds + (ulong)(gameObject.GetComponent<ballCollider>().obstacles) - (ulong)(gameObject.GetComponent<ballCollider>().goals * 5);
                        PanelGameover.transform.Find("gameoverGrade").GetComponent<Text>().text = "用时:"
                            + overGrade + "秒";
                        localOverGrade = overGrade;
                        int num = 0;

                        foreach(NetGrade gradeTemp in BackDescAllPlayers())
                        {
                            
                            num++;
                            if (gradeTemp.Name.Equals(Network.player.ipAddress))
                            {
                                Rank.GetComponent<Text>().text = string.Format("第{0}名",num);
                            }

                            Debug.Log("ip:" + gradeTemp.Name + "sj:" + gradeTemp.Time);
                        }

                        Debug.Log("num:" + num);
                        PanelGameover.SetActive(true);
                        flag = false;
                    }
                    else
                    {
                        //未到达终点的人出现“未完成！！！”，且不会弹出结束面板
                        if (temp)
                        {

                            GameObject.Find("count").GetComponent<Text>().text = "未完成!!!";
                            mainBack.SetActive(true);
                            temp = false;
                        }
                    }
                }
            }
        }
    }


    private List<NetGrade> BackDescAllPlayers()
    {

        GameObject[] balls = GameObject.FindGameObjectsWithTag("Player");
        List<NetGrade> list = new List<NetGrade>();
        int num = 0;
        foreach(GameObject ballTemp in balls)
        {
            num++;
            Debug.Log("allgrade:" + ballTemp.GetComponent<MyBallController>().localOverGrade);
            if (ballTemp.GetComponent<MyBallController>().localOverGrade != 0)
            {
                Debug.Log(ballTemp.GetComponent<MyBallController>().IPBall + int.Parse(ballTemp.GetComponent<MyBallController>().localOverGrade.ToString()));
                list.Add(new NetGrade(ballTemp.GetComponent<MyBallController>().IPBall, int.Parse(ballTemp.GetComponent<MyBallController>().localOverGrade.ToString())));
            }
        }
        Debug.Log("numbackasda:" + num);
        list = list.OrderBy<NetGrade, int>(grd => grd.Time).ToList();
        return list;
    }

    public List<int> BackDescList(Hashtable hs)
    {
        List<int> test = new List<int>();
        foreach (DictionaryEntry all in hs)
        {
            test.Add(int.Parse(all.Value.ToString()));
        }
        test.Sort();
        return test;
    }

    private void FixedUpdate()
    {
        //如果是本地玩家就可以移动
        if (isLocalPlayer)
        {
            //当房主开始游戏时GameOverObj.GetComponent<NetGameover>().AllPlayersGameover为真,且本地玩家还没到终点,transform.GetComponent<ballCollider>().localGameOver为false
            
            if (!transform.GetComponent<ballCollider>().localGameOver && !GameOverObj.GetComponent<NetGameover>().AllPlayersGameover && GameOverObj.GetComponent<NetGameover>().AllPlayersStart)
            {
                if (sliderSpeed.value != 100)
                    {
                        sliderSpeed.value = sliderSpeed.value + (float)0.1;
                    }
                    // Call the Move function of the ball controller
                    ball.Move(move, jump);
                    jump = false;
            }
        }


    }
}