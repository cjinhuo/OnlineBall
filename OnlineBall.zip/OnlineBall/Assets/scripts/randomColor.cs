﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class randomColor : MonoBehaviour {


    private void FixedUpdate()
    {
        //挂到random上面
        //随机生成颜色
        this.GetComponent<Renderer>().material.color = new Color(Random.Range(0f, 1f), Random.Range(0f, 1f), Random.Range(0f, 1f));
        //自动旋转  
        this.GetComponent<Transform>().Rotate(0, 180 * Time.deltaTime, 0, Space.Self);
    }
}
